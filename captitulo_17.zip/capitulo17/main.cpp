/* 
 * File:   main.cpp
 * Author: iper
 *
 * Created on 8 de diciembre de 2017, 6:57
 */

#include <cstdlib>
#include "hospi.hpp"
#include "hospi.cpp"
using namespace std;

/*
 * 
 */
void final(){
    //dis::Bdisco maquina;
    dis::lista list(20);
}
int main(int argc, char** argv) {
    final();
    return 0;
}

